"use strict";
cc._RF.push(module, '1f285q3kD9J1I9TMHk2xpFF', 'Popup');
// Script/Popup.js

'use strict';

// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

var mEmitter = require("EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        instruction: cc.PageView,
        option: cc.Layout,
        quit: cc.Layout
    },

    showWindow: function showWindow(popupWindow) {
        popupWindow.node.active = true;
        popupWindow.opacity = 0;
        popupWindow.scale = 0.3;

        cc.tween(popupWindow.node).to(0.4, { scale: 1.5, opacity: 255 }, { easing: 'bounceOut' }).call(function () {
            return cc.log('OK');
        }).start();
    },
    clickPopup: function clickPopup(str) {
        var popupWindow = null;
        if (str === 'Option') popupWindow = this.option;else if (str === 'Quit') popupWindow = this.quit;else popupWindow = this.instruction;
        this.showWindow(popupWindow);
    },
    hideInstruction: function hideInstruction() {
        var _this = this;

        cc.tween(this.instruction.node).to(0.4, { scale: 0.3, opacity: 0 }, { easing: 'bounceIn' }).call(function () {
            return _this.instruction.node.active = false;
        }).start();
    },
    hideOption: function hideOption() {
        var _this2 = this;

        cc.tween(this.option.node).to(0.4, { scale: 0.3, opacity: 0 }, { easing: 'bounceIn' }).call(function () {
            return _this2.option.node.active = false;
        }).start();
    },
    hideQuit: function hideQuit() {
        var _this3 = this;

        cc.tween(this.quit.node).to(0.4, { scale: 0.3, opacity: 0 }, { easing: 'bounceIn' }).call(function () {
            return _this3.quit.node.active = false;
        }).start();
    },


    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        mEmitter.instance.registerEvent('showPopup', this.clickPopup.bind(this));
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
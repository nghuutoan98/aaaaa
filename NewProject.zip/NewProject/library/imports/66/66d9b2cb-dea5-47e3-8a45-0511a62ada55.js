"use strict";
cc._RF.push(module, '66d9bLL3qVH44pFBRGmKtpV', 'btnNextBack');
// Script/btnNextBack.js

'use strict';

// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

var mEmitter = require('./EmitterClass');
cc.Class({
    extends: cc.Component,

    properties: {
        btnBack: cc.Button,
        btnNext: cc.Button
    },

    // LIFE-CYCLE CALLBACKS:

    clickBack: function clickBack() {
        mEmitter.instance.emit('scroll', true);
        this.btnNext.node.active = true;
        this.btnBack.node.active = false;
    },
    clickNext: function clickNext() {
        mEmitter.instance.emit('scroll', false);
        this.btnNext.node.active = false;
        this.btnBack.node.active = true;
    },
    onLoad: function onLoad() {
        this.btnBack.node.active = false;
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
"use strict";
cc._RF.push(module, 'f88e63++01EOarB3scMPtm9', 'ScoringNodeController');
// Script/ScoringNodeController.js

'use strict';

// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

var mEmitter = require("EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        HP: cc.ProgressBar,
        SP: cc.ProgressBar,
        score: cc.Label,
        _score: 0
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        mEmitter.instance.registerEvent('eaten', this.eatFood.bind(this));
        mEmitter.instance.registerEvent('over', this.gameOver.bind(this));
    },
    start: function start() {},
    gameOver: function gameOver() {
        mEmitter.instance.emit('gameOver', this._score);
    },
    eatFood: function eatFood(bool, id) {
        var HPVal = 0;
        var SPVal = 0;
        var scoreVal = 0;
        if (id == 1) {
            HPVal = 1 / 8;
            SPVal = 1 / 8;
            scoreVal = 1;
        } else if (id == 2) {
            HPVal = 1 / 6;
            SPVal = 1 / 6;
            scoreVal = 1;
        } else if (id == 3) {
            HPVal = 1 / 10;
            SPVal = 1 / 10;
            scoreVal = 2;
        } else if (id == 4) {
            HPVal = 1 / 4;
            SPVal = 1 / 4;
            scoreVal = 2;
        }
        this.updateHPBar(HPVal);
        this.updateSPBar(SPVal);
        this.updateScore(scoreVal);
    },
    updateSPBar: function updateSPBar(value) {
        this.SP.progress += value;
    },
    updateHPBar: function updateHPBar(value) {
        this.HP.progress += value;
    },
    updateScore: function updateScore(value) {
        this._score += value;
        this.score.string = this._score;
    },
    update: function update(dt) {
        this.SP.progress -= 1 / 30 * dt;
        if (this.SP.progress <= 0) this.gameOver();
    }
});

cc._RF.pop();
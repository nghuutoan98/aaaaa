(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Snake.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0716fa3abZH6ZFkBtsGRE2D', 'Snake', __filename);
// Script/Snake.js

'use strict';

// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

var mEmitter = require('EmitterClass');
cc.Class({
    extends: cc.Component,

    properties: {
        _turning: false,
        _eatFood: false,
        _isLose: false
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
        mEmitter.instance.registerEvent('eaten', this.eatFood.bind(this));
    },
    eatFood: function eatFood() {
        this._eatFood = true;
    },
    moveFoward: function moveFoward(dt) {
        //cc.log(this.node.angle);
        var angle = this.node.angle;
        if (this.node.angle === -180) angle = 180;else if (this.node.angle === -270) angle = 90;else if (this.node.angle === -90) angle = 270;
        this.node.angle = angle;
        if (angle % 360 === 0) {
            this.node.y += 100 * dt;
        }

        if (angle % 360 === 90) {
            this.node.x -= 100 * dt;
        }

        if (angle % 360 === 180) {
            this.node.y -= 100 * dt;
        }

        if (angle % 360 === 270) {
            this.node.x += 100 * dt;
        }
    },
    turn: function turn(angle) {
        var _this = this;

        cc.log(this._turning);
        if (!this._turning) {
            this._turning = true;
            //cc.log(this._turning);
            var rotate = cc.rotateBy(0.2, angle);
            var change = cc.callFunc(function () {
                _this._turning = false;
            });
            var seq = cc.sequence(rotate, change);
            this.node.runAction(seq);
        }
    },


    onCollisionEnter: function onCollisionEnter(other, self) {
        this.hitObstacle();

        //this._eatFood = false;
    },

    hitObstacle: function hitObstacle() {
        if (!this._eatFood) {
            this._isLose = true;
            this.node.stopAllActions();
            cc.tween(this.node).to(1, { scale: 0, opacity: 0 }).call(function () {
                mEmitter.instance.emit('over');
            }).start();
        } else this._eatFood = false;
    },


    onKeyDown: function onKeyDown(event) {
        switch (event.keyCode) {
            case cc.macro.KEY.a:
                this.turn(-90);
                break;
            case cc.macro.KEY.d:
                this.turn(90);
                break;
        }
    },

    onKeyUp: function onKeyUp(event) {
        switch (event.keyCode) {
            case cc.macro.KEY.a:
                //console.log('release a key');
                break;
            case cc.macro.KEY.d:
                //console.log('release d key');
                break;
        }
    },

    start: function start() {},
    update: function update(dt) {
        if (!this._isLose) this.moveFoward(dt);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Snake.js.map
        
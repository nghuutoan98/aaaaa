(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/GameOverController.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7e01b3bsJRA7orZj7nnHaHw', 'GameOverController', __filename);
// Script/GameOverController.js

'use strict';

// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

var mEmitter = require("./EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        reason: cc.RichText,
        score: cc.RichText,
        btnOK: cc.Button,
        gameOver: cc.Layout
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        mEmitter.instance.registerEvent('gameOver', this.over.bind(this));
    },
    start: function start() {},
    over: function over(score) {
        this.showWindow();
        this.updateScore(score);
    },
    showWindow: function showWindow() {
        this.gameOver.node.active = true;
        this.opacity = 0;
        this.scale = 0.3;

        cc.tween(this.gameOver.node).to(0.4, { scale: 4, opacity: 255 }, { easing: 'bounceOut' }).start();
    },
    updateScore: function updateScore(sco) {
        var str = '<color=#FF0000><size=80>' + sco + '</size></c>';
        this.score.string = str;
    },
    hideWindow: function hideWindow() {
        var _this = this;

        cc.tween(this.gameOver.node).to(0.4, { scale: 0.3, opacity: 0 }, { easing: 'bounceIn' }).call(function () {
            return _this.gameOver.node.active = false;
        }).start();
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameOverController.js.map
        
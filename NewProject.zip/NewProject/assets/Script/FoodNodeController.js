// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const mEmitter = require("EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        rabbit: cc.Prefab,
        mouse: cc.Prefab,
        bird: cc.Prefab,
        egg: cc.Prefab,
        _time: 0,
        _isOverlap: false,
        _food: cc.Prefab,
        _isCreate: true,
        _existTime: 0,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        mEmitter.instance.registerEvent('collide', this.collide.bind(this));
        mEmitter.instance.registerEvent('eaten', this.eaten.bind(this));
        this.generateFood();
    },

    start() {

    },

    collide: function (isCollide) {
        if (isCollide) {
            this.reCreateFood();
        }
    },

    eaten: function (isEaten,id) {
        if (isEaten) {
            this.reCreateFood();
            // this.generateExistTime(id);
        }
    },

    generateExistTime(id) {
        if(id === 1) {
            this._existTime = 10;
        } else if(id === 2) {
            this._existTime = 9;
        } else if(id === 3) {
            this._existTime = 8;
        } else if(id === 4) {
            this._existTime = 8;
        }
    },

    generateFood() {
        let x = Math.random() * (960 * 0.9);
        let y = Math.random() * (640 * 0.9);
        let random = Math.round(Math.random() * (4 - 1) + 1);
        if (random === 1) {
            this._food = cc.instantiate(this.rabbit);
        } else if (random === 2) {
            this._food = cc.instantiate(this.mouse);
        } else if (random === 3) {
            this._food = cc.instantiate(this.bird);
        } else this._food = cc.instantiate(this.egg);
        this._food.x = x;
        this._food.y = y;
        this.node.addChild(this._food);
    },

    reCreateFood() {
        this._food.destroy();
        this.generateFood();
        this._time = 0;
    },

    update(dt) {
        this._time += dt;
        if (this._time >= 10) {
            this.reCreateFood();
        }
    },
});

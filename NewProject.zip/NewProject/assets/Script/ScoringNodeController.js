// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const mEmitter = require("EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        HP: cc.ProgressBar,
        SP: cc.ProgressBar,
        score: cc.Label,
        _score: 0
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        mEmitter.instance.registerEvent('eaten', this.eatFood.bind(this));
        mEmitter.instance.registerEvent('over',this.gameOver.bind(this));
    },

    start () {

    },

    gameOver() {
        mEmitter.instance.emit('gameOver',this._score);
    },

    eatFood(bool,id) {
        let HPVal = 0;
        let SPVal = 0;
        let scoreVal = 0;
        if(id == 1) {
            HPVal = 1/8;
            SPVal = 1/8;
            scoreVal = 1;
        } else if(id == 2) {
            HPVal = 1/6;
            SPVal = 1/6;
            scoreVal = 1;
        } else if(id == 3) {
            HPVal = 1/10;
            SPVal = 1/10;
            scoreVal = 2;
        } else if(id == 4) {
            HPVal = 1/4;
            SPVal = 1/4;
            scoreVal = 2;
        }
        this.updateHPBar(HPVal);
        this.updateSPBar(SPVal);
        this.updateScore(scoreVal);
    },

    updateSPBar(value) {
        this.SP.progress += value;
    },

    updateHPBar(value) {
        this.HP.progress += value;
    },

    updateScore(value) {
        this._score += value
        this.score.string = this._score;
    },

    update (dt) {
        this.SP.progress -= 1 / 30 * dt;
        if(this.SP.progress <= 0) this.gameOver();
    },
});

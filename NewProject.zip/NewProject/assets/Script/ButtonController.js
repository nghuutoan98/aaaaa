// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const mEmitter = require("./EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        btnOption: cc.Button,
        btnQuit: cc.Button,
        btnInstruction: cc.Button,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.btnInstruction.node.on('mousedown',this.clickInstruction.bind(this));
        this.btnQuit.node.on('mousedown',this.clickQuit.bind(this));
        this.btnOption.node.on('mousedown',this.clickOption.bind(this));
    },

    clickInstruction() {
        mEmitter.instance.emit('showPopup','Instruction');
    },

    clickOption() {
        mEmitter.instance.emit('showPopup','Option');
    },

    clickQuit() {
        mEmitter.instance.emit('showPopup','Quit');
    },

    start () {

    },

    // update (dt) {},
});

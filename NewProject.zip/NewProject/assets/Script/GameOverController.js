// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const mEmitter = require("./EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        reason: cc.RichText,
        score: cc.RichText,
        btnOK: cc.Button,
        gameOver: cc.Layout,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        mEmitter.instance.registerEvent('gameOver',this.over.bind(this));
    },

    start () {

    },

    over(score) {
        this.showWindow();
        this.updateScore(score);
    },

    showWindow() {
        this.gameOver.node.active = true;
        this.opacity = 0;
        this.scale = 0.3;

        cc.tween(this.gameOver.node)
        .to(0.4,{scale:4, opacity:255},{easing:'bounceOut'})
        .start();
    },

    updateScore(sco) {
        let str = '<color=#FF0000><size=80>' + sco + '</size></c>';
        this.score.string = str;
    },

    hideWindow() {
        cc.tween(this.gameOver.node)
        .to(0.4,{scale:0.3, opacity:0},{easing:'bounceIn'})
        .call(() => this.gameOver.node.active = false)
        .start();
    },

    // update (dt) {},
});

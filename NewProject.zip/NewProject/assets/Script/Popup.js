// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const mEmitter = require("EmitterClass");

cc.Class({
    extends: cc.Component,

    properties: {
        instruction: cc.PageView,
        option: cc.Layout,
        quit: cc.Layout,        
    },

    showWindow(popupWindow) {
        popupWindow.node.active = true;
        popupWindow.opacity = 0;
        popupWindow.scale = 0.3;

        cc.tween(popupWindow.node)
        .to(0.4,{scale:1.5, opacity:255},{easing:'bounceOut'})
        .call(() => cc.log('OK'))
        .start();
    },

    clickPopup(str) {
        let popupWindow = null;
        if(str === 'Option') popupWindow = this.option;
        else if(str === 'Quit') popupWindow = this.quit;
        else popupWindow = (this.instruction);
        this.showWindow(popupWindow);
    },

    hideInstruction() {
        cc.tween(this.instruction.node)
        .to(0.4,{scale:0.3, opacity:0},{easing:'bounceIn'})
        .call(() => this.instruction.node.active = false)
        .start();
    },

    hideOption() {
        cc.tween(this.option.node)
        .to(0.4,{scale:0.3, opacity:0},{easing:'bounceIn'})
        .call(() => this.option.node.active = false)
        .start();
    },

    hideQuit() {
        cc.tween(this.quit.node)
        .to(0.4,{scale:0.3, opacity:0},{easing:'bounceIn'})
        .call(() => this.quit.node.active = false)
        .start();
    },

    // LIFE-CYCLE CALLBACKS:

   onLoad () {
       mEmitter.instance.registerEvent('showPopup',this.clickPopup.bind(this));
   },

    start () {

    },

    // update (dt) {},
});
